================================
Tridentstream Client for Kodi
================================


`Check out the repository to install this <https://kodi.tridentstream.org/>`_

This repository contains all the dependencies because Kodi decided to do their
own package and dependency management.