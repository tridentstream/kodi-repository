================================
Changelog
================================


Version 1.0.1 (26-01-2019)
--------------------------------

* Changed verify ssl to be default off due to problems.

Version 1.0.0 (12-12-2019)
--------------------------------

* Initial release