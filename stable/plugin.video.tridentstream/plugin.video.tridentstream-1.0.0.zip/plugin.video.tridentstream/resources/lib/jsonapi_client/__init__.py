from .client import JSONAPIClient, FailedToFetchDocumentException # noqa
from .resource import ResourceObject # noqa

__version__ = '0.1.0'